# ide-eval-resetter
Reset Your IDE Eval Information

* Download and install plugin from Release Page.
* Click Help or Get Help -> Reset IDE Eval menu.
* Restart your IDE.
* Now you have another 30 days eval time :)

